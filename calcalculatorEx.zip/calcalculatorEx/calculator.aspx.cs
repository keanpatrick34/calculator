﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class calculator : System.Web.UI.Page
{
    string numVal;
    DataTable dtMemory;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack) {
            Session["sMHList"] = null;
            Session["isPercent"] = false;
        }
        numVal = numTxt.Text  ;
        var valueList = memoryList.Items;
        string[] mlist = HiddenField1.Value.Split(',');
        memoryList.Items.Clear();
        for (int i = 0; i < mlist.Count(); i++)
        {
            if (!mlist[i].ToString().Equals("")) { 
            memoryList.Items.Add(mlist[i].ToString());
            }
        }
        if(memoryList.Items.Count > 0) {
            memoryPlusMinus.Value = memoryList.Items[0].ToString();
        }
        
    }

    protected void valueClick(object sender, EventArgs e)
    {
        if (!Convert.ToBoolean(Session["isPercent"])) {
            clear_Click(sender,e);
        }
        switch (((System.Web.UI.WebControls.Button)sender).Text)
        {
            case "1":
                numTxt.Text = numTxt.Text + "1";
                break;
            case "2":
                numTxt.Text = numTxt.Text + "2";
                break;
            case "3":
                numTxt.Text = numTxt.Text + "3";
                break;
            case "4":
                numTxt.Text = numTxt.Text + "4";
                break;
            case "5":
                numTxt.Text = numTxt.Text + "5";
                break;
            case "6":
                numTxt.Text = numTxt.Text + "6";
                break;
            case "7":
                numTxt.Text = numTxt.Text + "7";
                break;
            case "8":
                numTxt.Text = numTxt.Text + "8";
                break;
            case "9":
                numTxt.Text = numTxt.Text + "9";
                break;
            default:
                numTxt.Text = numTxt.Text + "0";
                break;
        }
        Session["isPercent"] = true;
    }

    protected void dot_Click(object sender, EventArgs e)
    {
        if (!numVal.Contains("."))
        {
            numVal = numTxt.Text + ".";
            numTxt.Text = numVal;
        }
    }

    protected void backSpace_Click(object sender, EventArgs e)
    {
        numTxt.Text = numTxt.Text.Remove(numTxt.Text.Length - 1, 1);
        if (numTxt.Text.Length == 0 || numTxt.Text.Equals("-"))
        {
            numTxt.Text = "0";
        }
    }

    protected void clear_Click(object sender, EventArgs e)
    {
        numTxt.Text = "";
    }

    protected void clearAll_Click(object sender, EventArgs e)
    {
        onDeckNum.Text = Convert.ToBoolean(Session["isPercent"]) ? "" : onDeckNum.Text;
        MDAS.Text = "";
        numTxt.Text = "";
    }

    protected void zero_Click(object sender, EventArgs e)
    {
        Session["isPercent"] = false;
        if (numTxt.Text.Equals("0"))
        {
            numTxt.Text = "0";
        }
        else numTxt.Text = numTxt.Text + "0";
    }


    protected void oneDivideBy_Click(object sender, EventArgs e)
    {
        Session["isPercent"] = false;
        if (onDeckNum.Text.Contains("/("))
        {
            onDeckNum.Text = "1/(" + onDeckNum.Text + ")";
        }
        else onDeckNum.Text = "1/(" + numTxt.Text + ")";

        numTxt.Text = Convert.ToDouble(new DataTable().Compute(onDeckNum.Text, numTxt.Text)).ToString();
    }

    protected void posiNega_Click(object sender, EventArgs e)
    {
        numTxt.Text = numTxt.Text.Equals("") ? "0" :(Convert.ToDouble(numTxt.Text) * -1).ToString();
    }

    protected void square_Click(object sender, EventArgs e)
    {
        Session["isPercent"] = true;
        onDeckNum.Text = "sqr(" + numTxt.Text + ")";
        numTxt.Text = (Convert.ToDouble(numTxt.Text) * Convert.ToDouble(numTxt.Text)).ToString();         
    }

    private bool squareChecker(string value)
    {
        Session["isPercent"] = true;
        if (!onDeckNum.Text.Contains("sqm")) return false;
        else return true;
    }

    protected void operatorList_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["isPercent"] = false;
        operatorList.Items.Remove(operatorList.Items.FindByValue("toBeRemove"));
        onDeckNum.Text = onDeckNum.Text.Equals("") ? numTxt.Text : onDeckNum.Text;
        numTxt.Text = "";
        if (operatorList.SelectedValue.Equals("+"))
        {
            MDAS.Text = "+";
            equalsBTN.Enabled = true;
        }
        else if (operatorList.SelectedValue.Equals("-"))
        {
            MDAS.Text = "-";
            equalsBTN.Enabled = true;
        }
        else if (operatorList.SelectedValue.Equals("*"))
        { 
            MDAS.Text = "*";
            equalsBTN.Enabled = true;
        }
        else if (operatorList.SelectedValue.Equals("/"))
        {
            MDAS.Text = "÷";
            equalsBTN.Enabled = true;
        }
        else {
            equalsBTN.Enabled = false;
        }
    }
    protected void computeTotal()
    {
        try { 
        numVal = Convert.ToDouble(new DataTable().Compute((Convert.ToDouble(onDeckNum.Text.Equals("") ? "0" : onDeckNum.Text) + (MDAS.Text.Equals("") ? "+" : MDAS.Text) + (numTxt.Text.Equals("") ? "0" : numTxt.Text)).ToString(), null)).ToString();
        }
        catch(Exception e)
        {
            numVal = "Error";
        }
        onDeckNum.Text = numTxt.Text;
        numTxt.Text = numVal;
    }

    protected void equals_Click(object sender, EventArgs e)
    {
        if (onDeckNum.Text.Contains("sqr") || onDeckNum.Text.Contains("/"))
        {
            MDAS.Text = "";
        }
        else if (MDAS.Text.Equals(""))
        {
            MDAS.Text = onDeckNum.Text;
            Session["isPercent"] = true;
        }      
        else if (!Convert.ToBoolean(Session["isPercent"])) {
            try
            {
                onDeckNum.Text = Convert.ToDouble(new DataTable().Compute((Convert.ToDouble(onDeckNum.Text.Equals("") ? "0" : onDeckNum.Text) + (MDAS.Text.Equals("") ? "+" : MDAS.Text) + (numTxt.Text)).ToString(), null)).ToString();
            }
            catch (Exception ex) {
                onDeckNum.Text = "";
                numTxt.Text = "Error";
            }
        }
        else computeTotal();
        List<memoryHistory> mHList;
        memoryHistory mH = new memoryHistory();
        mHList = (List<memoryHistory>)Session["sMHList"];
        if (mHList == null) {
            mHList = new List<memoryHistory>();
            mH.Hist_ID = mHList.Count + 1;
            mH.Hist_Action = onDeckNum.Text.Equals("") ? "=" : MDAS.Text;
            mH.Hist_Value = Convert.ToBoolean(Session["isPercent"]) ? numVal : onDeckNum.Text;
            mHList.Add(mH);            
        }
        else
        {
            mH.Hist_ID = mHList.Count + 1;
            mH.Hist_Action = onDeckNum.Text.Equals("") ? "=" : MDAS.Text;
            mH.Hist_Value = Convert.ToBoolean(Session["isPercent"]) ? numVal : onDeckNum.Text;
            mHList.Add(mH);
        }
        Session["sMHList"] = mHList;
        GridView1.DataSource = mHList;
        GridView1.DataBind();
        clear_Click(sender, e);
        numTxt.Text = numVal.Equals("Error") ? "0" : numVal;
    }

    protected void closeAspx(object sender, EventArgs e)
    {

        if (((System.Web.UI.WebControls.Menu)sender).SelectedItem.Value.Equals("Exit"))
        {
            this.ClientScript.RegisterClientScriptBlock(this.GetType(), "Close", "window.close()", true);
        }
        else if (((System.Web.UI.WebControls.Menu)sender).SelectedItem.Value.Equals("Copy"))
        {
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "copyValue()", true);
        }
        else if (((System.Web.UI.WebControls.Menu)sender).SelectedItem.Value.Equals("Paste"))
        {
            ScriptManager.RegisterStartupScript(this.Page, Page.GetType(), "text", "pasteValue()", true);
        }
        else equals_Click(sender, e);
    }
    protected void Button15_Click(object sender, EventArgs e)
    {
        if (!Convert.ToBoolean(Session["isPercent"]))
        {
            onDeckNum.Text = onDeckNum.Text.Equals("") ? "0" : numTxt.Text;
        }        
        numTxt.Text = Convert.ToDouble(new DataTable().Compute(((Convert.ToDouble(numTxt.Text) / 100) * Convert.ToDouble(onDeckNum.Text.Equals("") ? "0" : onDeckNum.Text)).ToString(), null)).ToString();
        Session["isPercent"] = false;
    }
    protected void exportToXML(object sender, EventArgs e)
    {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            foreach (TableCell cell in GridView1.HeaderRow.Cells)
            {
                dt.Columns.Add(cell.Text);
            }
            foreach (GridViewRow row in GridView1.Rows)
            {
                dt.Rows.Add();
                for (int i = 0; i < row.Cells.Count; i++)
                {
                    dt.Rows[row.RowIndex][i] = row.Cells[i].Text;
                }
            }
            ds.Tables.Add(dt);
            ds.WriteXml(Server.MapPath("XMLFile.xml"));
    }
    protected void importToXML(object sender, EventArgs e)
    {
        DataSet ds = new DataSet();
        ds.ReadXml(Server.MapPath("~/XMLFile.Xml"));
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }
}